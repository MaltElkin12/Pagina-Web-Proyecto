$(document).ready(function(){
    $("#particles-js").css({"height":$(window).height()+"px"});
});